package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "attendance_records")
data class AttendanceRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val studentId: Int,
    val studentName: String,
    val className: String,
    val date: String, // "yyyy-MM-dd"
    val isPresent: Boolean,
    val isOvertime: Boolean,
    val note: String,
    val timestamp: Long = System.currentTimeMillis()
)
