package com.example.data.repository

import android.util.Log
import com.example.data.db.StudentDao
import com.example.data.model.Student
import com.example.utils.GoogleSheetParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class StudentRepository(private val studentDao: StudentDao) {
    private val TAG = "StudentRepository"

    val allStudents: Flow<List<Student>> = studentDao.getAllStudents()
    val activeClasses: Flow<List<String>> = studentDao.getActiveClasses()

    fun getStudentsByClass(className: String): Flow<List<Student>> {
        return studentDao.getStudentsByClass(className)
    }

    /**
     * Seed initial fallback students to create a stellar zero-config first runtime of the app!
     */
    suspend fun seedInitialStudents() {
        withContext(Dispatchers.IO) {
            val currentClasses = activeClasses.first()
            if (currentClasses.isEmpty()) {
                Log.d(TAG, "Database is empty, seeding initial fallback student profiles.")
                studentDao.insertStudents(GoogleSheetParser.fallbackStudents)
            }
        }
    }

    /**
     * Downloads and parses students for each discovered tab inside the Google Sheets sheet file.
     */
    suspend fun syncWithGoogleSheets(spreadsheetUrl: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val discoveredTabs = GoogleSheetParser.fetchClasses(spreadsheetUrl)
            val allParsedStudents = mutableListOf<Student>()

            for (tab in discoveredTabs) {
                Log.d(TAG, "Fetching students for tab class: ${tab.name} (${tab.gid})")
                val studentsInTab = GoogleSheetParser.fetchStudentsFromTab(spreadsheetUrl, tab)
                allParsedStudents.addAll(studentsInTab)
            }

            if (allParsedStudents.isNotEmpty()) {
                // Perform transactional wipe and rebuild
                studentDao.deleteAllStudents()
                studentDao.insertStudents(allParsedStudents)
                Log.d(TAG, "Sync complete. Imported ${allParsedStudents.size} student profiles across ${discoveredTabs.size} classes.")
                Result.success(Unit)
            } else {
                Log.w(TAG, "Sync failed: no student records were resolved from the sheet.")
                Result.failure(Exception("Không thể tìm thấy danh sách học sinh hợp lệ nào từ tài liệu."))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in Google Sheets sync process", e)
            Result.failure(e)
        }
    }
}
