package com.example.data.repository

import com.example.data.db.AttendanceDao
import com.example.data.model.AttendanceRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class AttendanceRepository(private val attendanceDao: AttendanceDao) {

    val allAttendanceHistory: Flow<List<AttendanceRecord>> = attendanceDao.getAllAttendanceHistory()

    fun getAttendanceByDate(date: String): Flow<List<AttendanceRecord>> {
        return attendanceDao.getAttendanceByDate(date)
    }

    fun getAttendanceByDateAndClass(date: String, className: String): Flow<List<AttendanceRecord>> {
        return attendanceDao.getAttendanceByDateAndClass(date, className)
    }

    /**
     * Saves attendance records for a class on a specific day.
     * To support corrections/overwrites easily, it cleans previous attendance rows for this class-day combination
     * and writes the updated list atomically.
     */
    suspend fun saveAttendanceForClass(
        date: String,
        className: String,
        records: List<AttendanceRecord>
    ) = withContext(Dispatchers.IO) {
        // Delete records of this Class on this Date first to prevent stale rows
        attendanceDao.deleteAttendanceByDateAndClass(date, className)
        // Write the fresh list
        if (records.isNotEmpty()) {
            attendanceDao.insertAttendanceRecords(records)
        }
    }

    fun getAttendanceForStudent(studentId: Int): Flow<List<AttendanceRecord>> {
        return attendanceDao.getAttendanceForStudent(studentId)
    }
}
