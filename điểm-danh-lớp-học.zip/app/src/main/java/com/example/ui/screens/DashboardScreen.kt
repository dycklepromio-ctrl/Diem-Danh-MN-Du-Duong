package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.SyncStatus
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val todayAttendance by viewModel.todayAttendanceRecords.collectAsState()
    val allStudents by viewModel.allStudents.collectAsState()
    val activeClasses by viewModel.activeClasses.collectAsState()
    val selectedDate by viewModel.selectedDate.collectAsState()
    val spreadsheetUrl by viewModel.spreadsheetUrl.collectAsState()
    val syncStatus by viewModel.syncStatus.collectAsState()

    // Dialog state for edit spreadsheet link
    var showUrlDialog by remember { mutableStateOf(false) }
    var tempUrl by remember { mutableStateOf(spreadsheetUrl) }

    val totalStudents = allStudents.size
    val totalClasses = activeClasses.size
    val presentToday = todayAttendance.count { it.isPresent }
    // If no records taken yet, show 0 on progress but don't state as active absent
    val tookAttendance = todayAttendance.isNotEmpty()
    val absentToday = if (tookAttendance) todayAttendance.count { !it.isPresent } else 0
    val attendanceRate = if (totalStudents > 0 && tookAttendance) {
        (presentToday.toFloat() / totalStudents.toFloat())
    } else 0.0f

    // Format Vietnamese Date for display
    val calendar = Calendar.getInstance()
    val sfdIn = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val sfdOut = SimpleDateFormat("EEEE, 'ngày' dd 'tháng' MM, yyyy", Locale( "vi", "VN"))
    val displayDate = try {
        val parsedDate = sfdIn.parse(selectedDate) ?: Date()
        sfdOut.format(parsedDate)
    } catch (e: Exception) {
        selectedDate
    }

    Scaffold(
        topBar = {
            LargeTopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Tổng Quan Sĩ Số",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Thống kê & đồng bộ thời gian thực",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // 1. Date Selector Panel
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .clickable {
                            val parts = selectedDate.split("-")
                            if (parts.size == 3) {
                                val year = parts[0].toInt()
                                val month = parts[1].toInt() - 1
                                val day = parts[2].toInt()
                                DatePickerDialog(context, { _, y, m, d ->
                                    val newDate = String.format(Locale.getDefault(), "%d-%02d-%02d", y, m + 1, d)
                                    viewModel.updateSelectedDate(newDate)
                                }, year, month, day).show()
                            }
                        }
                        .padding(18.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Filled.DateRange,
                            contentDescription = "Chọn ngày",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Đang xem dữ liệu ngày:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = displayDate,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Icon(
                        Icons.Filled.ArrowDropDown,
                        contentDescription = "Mở lịch chọn",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // 2. Beautiful Gauge (Premium Attendance Wheel)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(28.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "TỈ LỆ CÓ MẶT TOÀN TRƯỜNG",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(170.dp)
                    ) {
                        val trackColor = MaterialTheme.colorScheme.surfaceVariant
                        val stateColor = MaterialTheme.colorScheme.primary
                        
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Draw background track ring
                            drawCircle(
                                color = trackColor,
                                radius = size.minDimension / 2.3f,
                                style = Stroke(width = 16.dp.toPx(), cap = StrokeCap.Round)
                            )
                            // Draw progress arc
                            val arcSize = size.minDimension / 1.15f
                            val offsetVal = (size.minDimension - arcSize) / 2f
                            drawArc(
                                brush = Brush.linearGradient(
                                    colors = listOf(stateColor, stateColor.copy(alpha = 0.6f))
                                ),
                                startAngle = -90f,
                                sweepAngle = if (tookAttendance) 360f * attendanceRate else 0f,
                                useCenter = false,
                                style = Stroke(width = 16.dp.toPx(), cap = StrokeCap.Round),
                                size = androidx.compose.ui.geometry.Size(arcSize, arcSize),
                                topLeft = androidx.compose.ui.geometry.Offset(offsetVal, offsetVal)
                            )
                        }

                        // Inside Ring texts
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            if (tookAttendance) {
                                Text(
                                    text = "${(attendanceRate * 100).toInt()}%",
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "$presentToday / $totalStudents em",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Icon(
                                    Icons.Default.Warning,
                                    contentDescription = "Chưa điểm danh",
                                    tint = MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Chưa điểm danh",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    if (!tookAttendance) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Lưu ý: Hôm nay giáo viên chưa bấm Lưu ở tab Điểm Danh nào.",
                                modifier = Modifier.padding(12.dp),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // 3. Score Grid Deck
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Total Student Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Icon(Icons.Filled.AccountBox, "Học sinh", tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Tổng sĩ số", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$totalStudents em", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("$totalClasses lớp học", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                // Present Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Icon(Icons.Filled.CheckCircle, "Có mặt", tint = Color(0xFF2E7D32))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Tổng có mặt", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$presentToday em", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                        Text(if (tookAttendance) "Đã hoàn thành" else "Chưa có dữ liệu", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                // Absent Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Icon(Icons.Filled.Close, "Vắng mặt", tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Tổng vắng", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$absentToday em", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                        val absentTxt = if (tookAttendance) "Cần theo dõi" else "Chưa có dữ liệu"
                        Text(absentTxt, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // 4. Synchronization Settings Section
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "ĐỒNG BỘ GOOGLE SHEETS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = { showUrlDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Sửa liên kết")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Đổi liên kết Google Sheets",
                            maxLines = 1,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Liên kết hiện tại:\n$spreadsheetUrl",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.syncStudents() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Đồng bộ")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Đồng Bộ Sĩ Số Thời Gian Thực", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }

    // Sheet Link Editor Dialog
    if (showUrlDialog) {
        AlertDialog(
            onDismissRequest = { showUrlDialog = false },
            title = { Text("Địa chỉ Google Sheets") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Nhập liên kết Google Sheets đã chia sẻ ở chế độ 'Người xem có thể truy cập' để lấy sĩ số:")
                    OutlinedTextField(
                        value = tempUrl,
                        onValueChange = { tempUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (tempUrl.isNotBlank()) {
                        viewModel.spreadsheetUrl.value = tempUrl
                    }
                    showUrlDialog = false
                }) {
                    Text("Xác nhận")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUrlDialog = false }) {
                    Text("Đóng")
                }
            }
        )
    }

    // Floating sync status notifications
    AnimatedVisibility(
        visible = syncStatus !is SyncStatus.Idle,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = when (syncStatus) {
                        is SyncStatus.Loading -> MaterialTheme.colorScheme.primaryContainer
                        is SyncStatus.Success -> Color(0xFFE8F5E9)
                        is SyncStatus.Error -> MaterialTheme.colorScheme.errorContainer
                        else -> MaterialTheme.colorScheme.surface
                    }
                ),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .padding(horizontal = 24.dp)
                    .fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    when (syncStatus) {
                        is SyncStatus.Loading -> {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = (syncStatus as SyncStatus.Loading).message,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        is SyncStatus.Success -> {
                            Icon(
                                Icons.Default.Check,
                                contentDescription = "Thành công",
                                tint = Color(0xFF2E7D32)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = (syncStatus as SyncStatus.Success).message,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1B5E20),
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { viewModel.setSyncStatusIdle() }) {
                                Icon(Icons.Default.Close, contentDescription = "Đóng", tint = Color(0xFF1B5E20))
                            }
                        }
                        is SyncStatus.Error -> {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = "Sự cố",
                                tint = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = (syncStatus as SyncStatus.Error).message,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { viewModel.setSyncStatusIdle() }) {
                                Icon(Icons.Default.Close, contentDescription = "Đóng", tint = MaterialTheme.colorScheme.onErrorContainer)
                            }
                        }
                        else -> {}
                    }
                }
            }
        }
    }
}
