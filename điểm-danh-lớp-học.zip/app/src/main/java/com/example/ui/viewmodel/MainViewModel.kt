package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.AttendanceRecord
import com.example.data.model.Student
import com.example.data.repository.AttendanceRepository
import com.example.data.repository.StudentRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

sealed interface SyncStatus {
    object Idle : SyncStatus
    data class Loading(val message: String) : SyncStatus
    data class Success(val message: String) : SyncStatus
    data class Error(val message: String) : SyncStatus
}

data class AttendanceDraft(
    val studentId: Int,
    val studentName: String,
    val className: String,
    val isPresent: Boolean = true,
    val isOvertime: Boolean = false,
    val note: String = ""
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val studentRepository = StudentRepository(database.studentDao())
    private val attendanceRepository = AttendanceRepository(database.attendanceDao())

    // 1. Spreadsheet URL Configuration
    val spreadsheetUrl = MutableStateFlow("https://docs.google.com/spreadsheets/d/1LmnX23ubRH4O-Sidqlc2CtokxohbHQ5d/edit?usp=sharing")

    // 2. Active Selected Contexts
    val selectedDate = MutableStateFlow(getCurrentDateString())
    val selectedClass = MutableStateFlow<String?>(null)

    // 3. Sync and Progress States (Toast or dialog bindings)
    private val _syncStatus = MutableStateFlow<SyncStatus>(SyncStatus.Idle)
    val syncStatus: StateFlow<SyncStatus> = _syncStatus

    // 4. Reactive List of Classrooms
    val activeClasses: StateFlow<List<String>> = studentRepository.activeClasses
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allStudents: StateFlow<List<Student>> = studentRepository.allStudents
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // 5. Active Interactive Attendance Draft List
    private val _attendanceDrafts = MutableStateFlow<List<AttendanceDraft>>(emptyList())
    val attendanceDrafts: StateFlow<List<AttendanceDraft>> = _attendanceDrafts

    // 6. Selected Date's Full Attendance (For Dashboard metrics and History)
    private val _todayAttendanceRecords = MutableStateFlow<List<AttendanceRecord>>(emptyList())
    val todayAttendanceRecords: StateFlow<List<AttendanceRecord>> = _todayAttendanceRecords

    // 7. Full Logs Repository Flow
    val allAttendanceHistory: StateFlow<List<AttendanceRecord>> = attendanceRepository.allAttendanceHistory
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Coordinated Jobs
    private var attendanceObserverJob: kotlinx.coroutines.Job? = null

    init {
        // Initial fallback seed database of students so the app feels instantly complete
        viewModelScope.launch {
            studentRepository.seedInitialStudents()
            // Pull first category selection
            activeClasses.collect { classes ->
                if (selectedClass.value == null && classes.isNotEmpty()) {
                    selectedClass.value = classes.first()
                }
            }
        }

        // Reactively reload active interactive grids when class or date toggles
        viewModelScope.launch {
            selectedClass.collect {
                loadAttendanceDrafts()
            }
        }

        viewModelScope.launch {
            selectedDate.collect { date ->
                loadAttendanceDrafts()
                observeTodayAttendance(date)
            }
        }
    }

    fun setSyncStatusIdle() {
        _syncStatus.value = SyncStatus.Idle
    }

    fun updateSelectedDate(dateString: String) {
        selectedDate.value = dateString
    }

    fun updateSelectedClass(className: String) {
        selectedClass.value = className
    }

    /**
     * Pulls the custom, interactive attendance logs from Room or initializes standard Present drafts.
     */
    fun loadAttendanceDrafts() {
        val currentClass = selectedClass.value ?: return
        val currentDate = selectedDate.value

        viewModelScope.launch {
            // Get all students of the class
            studentRepository.getStudentsByClass(currentClass).collect { students ->
                // Collect existing records
                attendanceRepository.getAttendanceByDateAndClass(currentDate, currentClass).collect { savedRecords ->
                    val savedMap = savedRecords.associateBy { it.studentId }
                    
                    val drafts = students.map { student ->
                        val saved = savedMap[student.id]
                        AttendanceDraft(
                            studentId = student.id,
                            studentName = student.name,
                            className = student.className,
                            isPresent = saved?.isPresent ?: true,
                            isOvertime = saved?.isOvertime ?: false,
                            note = saved?.note ?: ""
                        )
                    }
                    _attendanceDrafts.value = drafts
                }
            }
        }
    }

    /**
     * Saves user attendance logs back into Room. Overwrites previous records atomically to enable updates.
     */
    fun commitAttendance() {
        val currentClass = selectedClass.value ?: return
        val currentDate = selectedDate.value

        viewModelScope.launch {
            _syncStatus.value = SyncStatus.Loading("Đang ghi nhận điểm danh...")
            try {
                val recordsToSave = _attendanceDrafts.value.map { draft ->
                    AttendanceRecord(
                        studentId = draft.studentId,
                        studentName = draft.studentName,
                        className = draft.className,
                        date = currentDate,
                        isPresent = draft.isPresent,
                        isOvertime = draft.isOvertime,
                        note = draft.note
                    )
                }

                attendanceRepository.saveAttendanceForClass(currentDate, currentClass, recordsToSave)
                _syncStatus.value = SyncStatus.Success("Ghi nhận điểm danh lớp $currentClass ngày $currentDate thành công!")
            } catch (e: Exception) {
                _syncStatus.value = SyncStatus.Error("Không thể lưu: ${e.message}")
            }
        }
    }

    /**
     * Toggles attendance states in the working draft.
     */
    fun toggleStudentPresence(studentId: Int) {
        _attendanceDrafts.value = _attendanceDrafts.value.map { draft ->
            if (draft.studentId == studentId) {
                draft.copy(isPresent = !draft.isPresent)
            } else draft
        }
    }

    fun toggleStudentOvertime(studentId: Int) {
        _attendanceDrafts.value = _attendanceDrafts.value.map { draft ->
            if (draft.studentId == studentId) {
                draft.copy(isOvertime = !draft.isOvertime)
            } else draft
        }
    }

    fun updateStudentNote(studentId: Int, note: String) {
        _attendanceDrafts.value = _attendanceDrafts.value.map { draft ->
            if (draft.studentId == studentId) {
                draft.copy(note = note)
            } else draft
        }
    }

    /**
     * Downloads fresh student sheets from Google Sheets in real-time.
     */
    fun syncStudents() {
        val url = spreadsheetUrl.value
        if (url.isBlank()) {
            _syncStatus.value = SyncStatus.Error("Đường dẫn Google Sheets không hợp lệ!")
            return
        }

        viewModelScope.launch {
            _syncStatus.value = SyncStatus.Loading("Đang đồng bộ dữ liệu với Google Sheets thực tế...")
            val result = studentRepository.syncWithGoogleSheets(url)
            if (result.isSuccess) {
                _syncStatus.value = SyncStatus.Success("Đồng bộ danh sách học sinh thành công!")
                
                // Refresh class selections
                studentRepository.activeClasses.collect { classes ->
                    if (classes.isNotEmpty()) {
                        selectedClass.value = classes.first()
                    }
                }
            } else {
                _syncStatus.value = SyncStatus.Error(result.exceptionOrNull()?.message ?: "Sự cố khi liên kết dữ liệu.")
            }
        }
    }

    private fun observeTodayAttendance(date: String) {
        attendanceObserverJob?.cancel()
        attendanceObserverJob = viewModelScope.launch {
            attendanceRepository.getAttendanceByDate(date).collect { list ->
                _todayAttendanceRecords.value = list
            }
        }
    }

    private fun getCurrentDateString(): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return dateFormat.format(Date())
    }
}
