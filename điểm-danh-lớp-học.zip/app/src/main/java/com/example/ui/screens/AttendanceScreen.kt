package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.AttendanceDraft
import androidx.compose.ui.text.TextStyle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttendanceScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val activeClasses by viewModel.activeClasses.collectAsState()
    val selectedClass by viewModel.selectedClass.collectAsState()
    val attendanceDrafts by viewModel.attendanceDrafts.collectAsState()
    val selectedDate by viewModel.selectedDate.collectAsState()

    // Map tab items based on active classes
    val tabIndex = if (selectedClass != null) activeClasses.indexOf(selectedClass) else 0

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "Điểm Danh Lớp Học",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "Ngày: $selectedDate",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
                
                // Classroom Swipe/Categorizer Tabs
                if (activeClasses.isNotEmpty()) {
                    ScrollableTabRow(
                        selectedTabIndex = if (tabIndex >= 0) tabIndex else 0,
                        edgePadding = 16.dp,
                        containerColor = MaterialTheme.colorScheme.background,
                        indicator = { tabPositions ->
                            if (tabIndex >= 0 && tabIndex < tabPositions.size) {
                                TabRowDefaults.SecondaryIndicator(
                                    modifier = Modifier.tabIndicatorOffset(tabPositions[tabIndex]),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    ) {
                        activeClasses.forEachIndexed { index, className ->
                            Tab(
                                selected = selectedClass == className,
                                onClick = { viewModel.updateSelectedClass(className) },
                                text = {
                                    Text(
                                        text = "Lớp $className",
                                        fontWeight = if (selectedClass == className) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 14.sp
                                    )
                                },
                                selectedContentColor = MaterialTheme.colorScheme.primary,
                                unselectedContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            if (activeClasses.isEmpty()) {
                // Empty state trigger
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = "Không có lớp",
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Chưa có danh sách lớp học",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Vui lòng bấm 'Đồng Bộ Sĩ Số' ở màn hình chính để tải dữ liệu học sinh từ Google Sheets.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth(0.85f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else {
                val presentCount = attendanceDrafts.count { it.isPresent }
                val absentCount = attendanceDrafts.count { !it.isPresent }
                val overtimeCount = attendanceDrafts.count { it.isOvertime }

                Column(modifier = Modifier.fillMaxSize()) {
                    // Header Status Summary Panel for class
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            AssistChip(
                                onClick = { },
                                label = { Text("Có mặt: $presentCount") },
                                colors = AssistChipDefaults.assistChipColors(
                                    labelColor = Color(0xFF2E7D32)
                                )
                            )
                            AssistChip(
                                onClick = { },
                                label = { Text("Vắng: $absentCount") },
                                colors = AssistChipDefaults.assistChipColors(
                                    labelColor = MaterialTheme.colorScheme.error
                                )
                            )
                            AssistChip(
                                onClick = { },
                                label = { Text("Ngoài giờ: $overtimeCount") },
                                colors = AssistChipDefaults.assistChipColors(
                                    labelColor = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    }

                    // Student List Grid Scrollable
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        itemsIndexed(
                            items = attendanceDrafts,
                            key = { _, draft -> draft.studentId }
                        ) { index, draft ->
                            StudentAttendanceCard(
                                index = index + 1,
                                draft = draft,
                                onPresenceToggle = { viewModel.toggleStudentPresence(draft.studentId) },
                                onOvertimeToggle = { viewModel.toggleStudentOvertime(draft.studentId) },
                                onNoteChange = { viewModel.updateStudentNote(draft.studentId, it) }
                            )
                        }
                    }
                }

                // Sticky Footer Action Bar
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth(),
                    tonalElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Box(modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)) {
                        Button(
                            onClick = { viewModel.commitAttendance() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                                .height(52.dp),
                            shape = RoundedCornerShape(16.dp),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                        ) {
                            Icon(Icons.Default.Done, contentDescription = "Hoàn tất")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Xác Nhận & Lưu Điểm Danh Hôm Nay",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StudentAttendanceCard(
    index: Int,
    draft: AttendanceDraft,
    onPresenceToggle: () -> Unit,
    onOvertimeToggle: () -> Unit,
    onNoteChange: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (draft.isPresent) {
                MaterialTheme.colorScheme.surface
            } else {
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f)
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Row 1: STT, Full Name, Presence Trigger
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Circular Index Badge
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .background(
                            MaterialTheme.colorScheme.secondaryContainer,
                            RoundedCornerShape(8.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = index.toString(),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Name Details
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = draft.studentName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (draft.isPresent) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Presence Switch with dual labels and states
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onPresenceToggle() }
                        .background(
                            if (draft.isPresent) {
                                Color(0xFFE8F5E9)
                            } else {
                                MaterialTheme.colorScheme.errorContainer
                            }
                        )
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = if (draft.isPresent) Icons.Default.CheckCircle else Icons.Default.Close,
                        contentDescription = "Trạng thái",
                        tint = if (draft.isPresent) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (draft.isPresent) "Có mặt" else "Vắng",
                        color = if (draft.isPresent) Color(0xFF1B5E20) else MaterialTheme.colorScheme.onErrorContainer,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            // Row 2: Overtime Toggle & Custom Notes Entry
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Overtime (Ngoài giờ) Toggle
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onOvertimeToggle() }
                ) {
                    Checkbox(
                        checked = draft.isOvertime,
                        onCheckedChange = { onOvertimeToggle() },
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Điểm danh ngoài giờ",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Notes Field
                OutlinedTextField(
                    value = draft.note,
                    onValueChange = onNoteChange,
                    placeholder = { Text("Lý do / Ghi chú...", fontSize = 11.sp) },
                    modifier = Modifier
                        .fillMaxWidth(1f)
                        .height(40.dp),
                    shape = RoundedCornerShape(10.dp),
                    textStyle = TextStyle(fontSize = 12.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    singleLine = true
                )
            }
        }
    }
}
