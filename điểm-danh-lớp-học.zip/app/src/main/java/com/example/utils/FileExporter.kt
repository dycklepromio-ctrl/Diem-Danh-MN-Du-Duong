package com.example.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.model.AttendanceRecord
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets

object FileExporter {
    
    /**
     * Exports daily attendance records as an Excel-compatible CSV file.
     * Incorporates the UTF-8 BOM bytes (\uFEFF) to make Excel parse accented Vietnamese characters perfectly.
     */
    fun exportDailyAttendance(context: Context, date: String, records: List<AttendanceRecord>): File? {
        try {
            val reportsDir = File(context.cacheDir, "reports")
            if (!reportsDir.exists()) {
                reportsDir.mkdirs()
            }
            
            // Clean up old reports to prevent bloating cache
            reportsDir.listFiles()?.forEach { it.delete() }

            val cleanDate = date.replace("-", "_")
            val outputFile = File(reportsDir, "diem_danh_ngay_$cleanDate.csv")
            val fos = FileOutputStream(outputFile)
            
            // Write standard UTF-8 BOM bytes
            fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
            
            val writer = OutputStreamWriter(fos, StandardCharsets.UTF_8)
            writer.append("STT,Họ và Tên,Lớp,Ngày Điểm Danh,Trạng Thái,Ngoài Giờ (Bán trú/Tăng ca),Ghi Chú\n")

            records.forEachIndexed { index, record ->
                val status = if (record.isPresent) "Có mặt ✔" else "Vắng mặt ❌"
                val overtime = if (record.isOvertime) "Có" else "Không"
                val escapedName = escapeCsv(record.studentName)
                val escapedClass = escapeCsv(record.className)
                val escapedNote = escapeCsv(record.note)
                
                writer.append("${index + 1},$escapedName,$escapedClass,${record.date},$status,$overtime,$escapedNote\n")
            }
            
            writer.flush()
            writer.close()
            fos.close()
            return outputFile
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    private fun escapeCsv(content: String): String {
        if (content.contains(",") || content.contains("\"") || content.contains("\n")) {
            val escaped = content.replace("\"", "\"\"")
            return "\"$escaped\""
        }
        return content
    }

    /**
     * Spawns a system share sheet for the CSV report file.
     */
    fun shareReportFile(context: Context, file: File) {
        try {
            val authority = "${context.packageName}.fileprovider"
            val uri: Uri = FileProvider.getUriForFile(context, authority, file)
            
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/comma-separated-values"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Báo Cáo Điểm Danh")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            
            context.startActivity(Intent.createChooser(shareIntent, "Chia Sẻ Báo Cáo Excel"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Generates a notification text summarizing the daily classroom attendance.
     */
    fun formatGroupMessage(date: String, className: String, records: List<AttendanceRecord>): String {
        val presentCount = records.count { it.isPresent }
        val absentCount = records.count { !it.isPresent }
        val registeredOvertimeCount = records.count { it.isOvertime }
        val total = records.size

        val absentNames = records.filter { !it.isPresent }
            .joinToString(", ") { it.studentName }
            .ifEmpty { "Không có (Sĩ số đầy đủ)" }

        return """
🔔 THÔNG BÁO ĐIỂM DANH LỚP: LỚP $className
📅 Ngày: $date
━━━━━━━━━━━━━━━━━━━━
📊 Sĩ số học sinh: $total học sinh
✅ Có mặt chính khóa: $presentCount em
❌ Vắng mặt: $absentCount em 
📝 Danh sách vắng: $absentNames
⏰ Điểm danh ngoài giờ/bán trú: $registeredOvertimeCount em

Kính báo để quý phụ huynh và nhà trường theo dõi!
        """.trimIndent()
    }

    /**
     * Formats an individual notification for a parent about their child.
     */
    fun formatIndividualMessage(record: AttendanceRecord): String {
        val status = if (record.isPresent) "CÓ MẶT ở lớp" else "VẮNG MẶT hôm nay"
        val overtimeText = if (record.isOvertime) "\n⏰ Đăng ký ngoài giờ: CÓ" else ""
        val noteText = if (record.note.isNotEmpty()) "\n📝 Ghi chú: ${record.note}" else ""
        
        return """
🔔 THÔNG TIN ĐIỂM DANH: BÉ ${record.studentName.uppercase()}
📅 Ngày: ${record.date}  - Lớp: ${record.className}
━━━━━━━━━━━━━━━━━━━━
Trạng thái: Bé đã $status.
$overtimeText$noteText

Chúc phụ huynh và các em học sinh một ngày tốt lành!
        """.trimIndent()
    }

    /**
     * Opens a generic android share sheet with formatted text. 
     * Teachers can choose Zalo to send it directly to classroom parent groups or private Zalo chats.
     */
    fun shareTextMessage(context: Context, message: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
        }
        context.startActivity(Intent.createChooser(intent, "Gửi Thông Báo (Chọn Zalo / Tin Nhắn)"))
    }
}
