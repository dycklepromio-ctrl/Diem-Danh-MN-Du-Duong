package com.example.utils

import android.util.Log
import com.example.data.model.Student
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.regex.Pattern

object GoogleSheetParser {
    private const val TAG = "GoogleSheetParser"
    private val client = OkHttpClient()

    // Default classroom list in case extraction fails initially
    val fallbackClasses = listOf(
        SheetTab("Lá", "0")
    )

    // Uniquely structured fallback student list to make first launch experience awesome
    val fallbackStudents = listOf(
        "Lương Hoàng Khôi", "Nguyễn Lê Nhân Thùy", "Nguyễn Nhật Đăng", "Nguyễn Tấn Khải",
        "Nguyễn Thành Phát", "Phạm Bảo Trúc", "Phạm Nhật Bảo", "Phạm Võ Minh Phương",
        "Phan Lê Nhã Phương", "Bùi Ngọc Phương My", "Trần Đàm Bích Huyền", "Trần Đức Huy",
        "Trần Thảo Nguyên", "Trương Hoàng Ngân Khánh", "Võ Ngọc Bảo Nghi", "Đỗ Minh Khang",
        "Đoàn Ngọc Khả Hân", "Dương Minh Quân", "Huỳnh Triệu Bảo Ngọc", "Lê Nguyên Khang",
        "Mai Gia Hân", "Nguyễn Đoàn Tiến Khương", "Nguyễn Linh Đan", "Nguyễn Lộc Phát",
        "Nguyễn Ngọc Quỳnh Anh", "Nguyễn Trịnh Huy Hoàng", "Nguyễn Vĩnh Luân",
        "Trần Lê Gia Huy", "Trần Ngọc Hà", "Bùi Thị Ngọc Thảo"
    ).map { Student(name = it, className = "Lá") }

    /**
     * Extracts Google Sheet tabs (represents school classrooms) dynamically without requiring any API key.
     */
    fun fetchClasses(spreadsheetUrl: String): List<SheetTab> {
        val spreadsheetId = extractSpreadsheetId(spreadsheetUrl) ?: return fallbackClasses
        val htmlUrl = "https://docs.google.com/spreadsheets/d/$spreadsheetId/htmlview"
        
        val request = Request.Builder().url(htmlUrl).build()
        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Failed to fetch htmlview: ${response.code}")
                    return fallbackClasses
                }
                val html = response.body?.string() ?: ""
                val tabs = parseTabsFromHtml(html)
                return tabs.ifEmpty { fallbackClasses }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception fetching sheet classes", e)
            return fallbackClasses
        }
    }

    fun parseTabsFromHtml(html: String): List<SheetTab> {
        val tabs = mutableListOf<SheetTab>()
        
        // Match 1: HTML anchor elements with target gid #gid= or ?gid=
        val anchorRegex = """href="[^"]*[?#]gid=([0-9]+)"[^>]*>([^<]+)</a>""".toRegex()
        val matches = anchorRegex.findAll(html)
        for (match in matches) {
            val gid = match.groupValues[1]
            val name = match.groupValues[2].trim()
            // Ignore generic template names or helper sheets if they are empty
            if (name.isNotEmpty() && !name.contains("Bản sao") && !tabs.any { it.name == name }) {
                tabs.add(SheetTab(name, gid))
            }
        }

        // Match 2: Script elements inside bootstrapData
        if (tabs.isEmpty()) {
            val scriptRegex = """"(name|sheetName)"\s*:\s*"([^"]+)"\s*,\s*"(id|gid)"\s*:\s*"?([0-9]+)"?""".toRegex()
            val scriptMatches = scriptRegex.findAll(html)
            for (match in scriptMatches) {
                val name = match.groupValues[2].trim()
                val gid = match.groupValues[4]
                if (name.isNotEmpty() && !name.contains("Bản sao") && !tabs.any { it.name == name || it.gid == gid }) {
                    tabs.add(SheetTab(name, gid))
                }
            }
        }
        
        return tabs
    }

    /**
     * Fetches students list as Student entities for a specific SheetTab classroom.
     */
    fun fetchStudentsFromTab(spreadsheetUrl: String, tab: SheetTab): List<Student> {
        val spreadsheetId = extractSpreadsheetId(spreadsheetUrl) ?: return emptyList()
        val csvUrl = if (tab.gid == "0" || tab.gid.isEmpty()) {
            "https://docs.google.com/spreadsheets/d/$spreadsheetId/export?format=csv"
        } else {
            "https://docs.google.com/spreadsheets/d/$spreadsheetId/export?format=csv&gid=${tab.gid}"
        }

        val request = Request.Builder().url(csvUrl).build()
        val students = mutableListOf<Student>()
        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val csvContent = response.body?.string() ?: ""
                val lines = csvContent.split("\n")
                for (line in lines) {
                    val parts = line.split(",")
                    if (parts.size < 3) continue
                    
                    val name = parts[1].trim()
                    // Filter headers or empty lines
                    if (name.isEmpty() || name == "Họ tên" || name.startsWith("Họ tên")) continue
                    
                    val parsedClass = parts[2].trim()
                    val actualClass = if (parsedClass.isNotEmpty()) parsedClass else tab.name
                    students.add(Student(name = name, className = actualClass))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error matching students for ${tab.name}", e)
        }
        return students
    }

    fun extractSpreadsheetId(url: String): String? {
        if (url.isBlank()) return null
        val pattern = Pattern.compile("/d/([a-zA-Z0-9-_]+)")
        val matcher = pattern.matcher(url)
        return if (matcher.find()) matcher.group(1) else null
    }
}

data class SheetTab(val name: String, val gid: String)
